<?php
// Database connection parameters


$servername = "localhost";
$username = "root";
$password = "";
$database = "kevin_fang";


// Insert data into the SQL table
$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function formatPhoneNumber($number)
{
    // Remove any non-numeric characters from the input
    $number = preg_replace("/[^0-9]/", "", $number);

    // If the length of the number is 10, format it as (123)123-1234
    if (strlen($number) === 10) {
        $formattedNumber = "(" . substr($number, 0, 3) . ")" . substr($number, 3, 3) . "-" . substr($number, 6, 4);
    }
    // If the length of the number is 11 and it starts with 1, format it as (123)123-1234
    elseif (strlen($number) === 11 && substr($number, 0, 1) === "1") {
        $formattedNumber = "(" . substr($number, 1, 3) . ")" . substr($number, 4, 3) . "-" . substr($number, 7, 4);
    }
    // Otherwise, return the original number
    else {
        $formattedNumber = $number;
    }

    return $formattedNumber;
}